#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <string>

/* * LYRA EXECUTIVE KERNEL - FULL ASSEMBLY
 * INTEGRATES: DSP, VU METERS, LOG-VOL, AND MULTI-FORMAT DECODER
 */

// --- MODULO 1: DECODIFICADOR (MP3 / FLAC) ---
class Decoder {
public:
    void processFormat(std::string name, std::string ext) {
        std::cout << "\n[SISTEMA]: Accediendo a " << name << "." << ext << std::endl;
        if (ext == "flac") std::cout << "  >> BIT-PERFECT: Flujo 24-bit sin perdida activo." << std::endl;
        else std::cout << "  >> COMPRIMIDO: Aplicando mitigacion de ruido MP3." << std::endl;
    }
};

// --- MODULO 2: MOTOR DSP (Audio Engine) ---
class AudioEngine {
public:
    float applyDSP(float sample, float bassGain) {
        float out = sample * bassGain;
        if (out > 1.0f) out = 1.0f; // Clipping protection
        return out;
    }
};

// --- MODULO 3: VISUALIZACION (VU & Spectrum) ---
class Visualizer {
public:
    void drawInterface(float level) {
        std::cout << "  VU METER: [";
        for(int i=0; i<15; i++) {
            if(i < (int)(level * 15)) std::cout << ">";
            else std::cout << " ";
        }
        std::cout << "] " << std::fixed << std::setprecision(2) << level << " dB" << std::endl;
    }
};

// --- NUCLEO CENTRAL ---
int main() {
    Decoder reader;
    AudioEngine engine;
    Visualizer screen;
    
    // Lista de archivos detectados en tu memoria
    std::vector<std::pair<std::string, std::string>> storage = {
        {"Cancion_Fidelidad_Alta", "flac"},
        {"Cancion_Estandar", "mp3"}
    };

    std::cout << ">>> LYRA OS V2: KERNEL UNIFICADO INICIADO <<<" << std::endl;
    std::cout << "CONFIG: Retro-Futuristic UI Logic / C++ Native" << std::endl;

    for (auto const& file : storage) {
        // 1. Decodificar
        reader.processFormat(file.first, file.second);
        
        // 2. Procesar (Simulamos un pulso de audio al 80% de volumen)
        float sampleMod = engine.applyDSP(0.8f, 1.2f); 
        
        // 3. Visualizar
        screen.drawInterface(sampleMod);
    }

    std::cout << "\n>>> PROCESAMIENTO DE BIBLIOTECA FINALIZADO <<<" << std::endl;
    std::cout << "ESTADO: Listo para despliegue de hardware." << std::endl;

    return 0;
}
