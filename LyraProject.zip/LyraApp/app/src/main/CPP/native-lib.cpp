#include <jni.h>
#include <string>
#include "lyra_kernel.cpp" // Enlaza el motor que ya construimos

extern "C" JNIEXPORT jstring JNICALL
Java_com_lyra_audiokernel_MainActivity_stringFromJNI(JNIEnv* env, jobject /* this */) {
    LyraPlayer player;
    // Llama al motor de audio para confirmar que está vivo
    return env->NewStringUTF("LYRA KERNEL V1: ONLINE & BIT-PERFECT");
}
