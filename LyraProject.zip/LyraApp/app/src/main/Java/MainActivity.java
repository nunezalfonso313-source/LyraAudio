package com.lyra.audiokernel;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Carga el motor de C++ (el que probamos en Programiz)
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Aquí es donde se conectará con la imagen retro-futurista
        TextView tv = new TextView(this);
        tv.setText(stringFromJNI());
        setContentView(tv);
    }

    // Este es el "cable" que conecta con el C++
    public native String stringFromJNI();
}
